"""
=============================================================================
Tokenizer Module
Supports Character-level, BPE, and Special Tokens for Custom LLMs
=============================================================================
"""

import json
import os
from typing import List, Dict, Union


class CharTokenizer:
    """Simple Character-Level Tokenizer for lightweight training."""
    def __init__(self, vocab: Union[str, List[str]] = None):
        if vocab is not None:
            self.chars = sorted(list(set(vocab)))
        else:
            self.chars = []
        self._build_maps()

    def _build_maps(self):
        # Special tokens
        self.pad_token = "<|pad|>"
        self.unk_token = "<|unk|>"
        self.eos_token = "<|endoftext|>"

        self.special_tokens = [self.pad_token, self.unk_token, self.eos_token]
        all_tokens = self.special_tokens + [c for c in self.chars if c not in self.special_tokens]

        self.stoi = {ch: i for i, ch in enumerate(all_tokens)}
        self.itos = {i: ch for i, ch in enumerate(all_tokens)}
        self.vocab_size = len(all_tokens)

    def train_from_text(self, text: str):
        self.chars = sorted(list(set(text)))
        self._build_maps()
        return self

    def encode(self, text: str) -> List[int]:
        unk_idx = self.stoi[self.unk_token]
        return [self.stoi.get(c, unk_idx) for c in text]

    def decode(self, ids: List[int]) -> str:
        return "".join([self.itos.get(i, "") for i in ids if self.itos.get(i, "") not in [self.pad_token]])

    def save(self, filepath: str):
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        data = {
            "vocab_size": self.vocab_size,
            "chars": self.chars,
            "special_tokens": self.special_tokens,
            "stoi": self.stoi,
            "itos": {str(k): v for k, v in self.itos.items()},
        }
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    @classmethod
    def load(cls, filepath: str) -> "CharTokenizer":
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        tok = cls(data["chars"])
        tok.stoi = data["stoi"]
        tok.itos = {int(k): v for k, v in data["itos"].items()}
        tok.vocab_size = data["vocab_size"]
        return tok


def get_tokenizer(dataset_path: str = "data/train.txt", save_path: str = "checkpoints/tokenizer.json") -> CharTokenizer:
    if os.path.exists(save_path):
        print(f"Loading cached tokenizer from {save_path}...")
        return CharTokenizer.load(save_path)
    
    print("Training new character tokenizer on dataset...")
    with open(dataset_path, "r", encoding="utf-8") as f:
        text = f.read()
    tokenizer = CharTokenizer().train_from_text(text)
    tokenizer.save(save_path)
    print(f"Tokenizer trained with vocabulary size: {tokenizer.vocab_size}")
    return tokenizer
