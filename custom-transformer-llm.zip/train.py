"""
=============================================================================
Nano-GPT (1.2M) Training Pipeline
Supports AdamW, Cosine Annealing LR Schedule, Mixed Precision & Checkpointing
=============================================================================
"""

import os
import time
import math
import yaml
import torch
from tqdm import tqdm

from model import CustomLLM
from tokenizer import get_tokenizer
from dataset import prepare_dataloaders


def get_lr(step: int, max_steps: int, warmup_steps: int, max_lr: float, min_lr: float) -> float:
    """Cosine Annealing learning rate schedule with linear warmup."""
    if step < warmup_steps:
        return max_lr * step / max(1, warmup_steps)
    if step > max_steps:
        return min_lr
    decay_ratio = (step - warmup_steps) / (max_steps - warmup_steps)
    assert 0 <= decay_ratio <= 1
    coeff = 0.5 * (1.0 + math.cos(math.pi * decay_ratio))
    return min_lr + coeff * (max_lr - min_lr)


@torch.no_grad()
def estimate_loss(model, dataloader, device, eval_iters=20):
    model.eval()
    losses = []
    for i, (x, y) in enumerate(dataloader):
        if i >= eval_iters:
            break
        x, y = x.to(device), y.to(device)
        _, loss, _ = model(x, y)
        losses.append(loss.item())
    model.train()
    mean_loss = sum(losses) / len(losses) if losses else 0.0
    perplexity = math.exp(min(mean_loss, 20.0))
    return mean_loss, perplexity


def train():
    device = "cuda" if torch.cuda.is_available() else ("mps" if torch.backends.mps.is_available() else "cpu")
    print(f"🚀 Training on device: {device.upper()}")

    # Setup directories
    os.makedirs("checkpoints", exist_ok=True)

    # Tokenizer & Data
    tokenizer = get_tokenizer("data/train.txt")
    with open("data/train.txt", "r", encoding="utf-8") as f:
        raw_text = f.read()
    
    tokens = tokenizer.encode(raw_text)
    print(f"Dataset tokenized: {len(tokens):,} total tokens.")

    train_loader, val_loader = prepare_dataloaders(
        tokens,
        block_size=256,
        batch_size=32,
        train_split=0.9,
    )

    # Initialize Model
    model = CustomLLM(
        vocab_size=tokenizer.vocab_size,
        n_layers=4,
        n_embd=128,
        n_head=4,
        block_size=256,
        dropout=0.05,
        norm_type="rmsnorm",
        activation="swiglu",
        positional_encoding="rope",
    ).to(device)

    total_params = sum(p.numel() for p in model.parameters())
    print(f"Model initialized: {total_params:,} parameters ({(total_params / 1e6):.2f}M)")

    # Optimizer
    optimizer = model.configure_optimizers(
        weight_decay=0.1,
        learning_rate=0.0005,
        betas=(0.9, 0.95),
        device_type=device,
    )

    # Training settings
    max_steps = 1000
    warmup_steps = 100
    max_lr = 0.0005
    min_lr = 0.00005
    grad_accum_steps = 4
    eval_interval = 100

    step = 0
    best_val_loss = float("inf")
    start_time = time.time()

    model.train()
    data_iter = iter(train_loader)

    pbar = tqdm(range(max_steps), desc="Training Steps")
    for step in pbar:
        # Learning rate schedule step
        lr = get_lr(step, max_steps, warmup_steps, max_lr, min_lr)
        for param_group in optimizer.param_groups:
            param_group["lr"] = lr

        optimizer.zero_grad(set_to_none=True)
        accum_loss = 0.0

        for micro_step in range(grad_accum_steps):
            try:
                x, y = next(data_iter)
            except StopIteration:
                data_iter = iter(train_loader)
                x, y = next(data_iter)

            x, y = x.to(device), y.to(device)
            _, loss, _ = model(x, y)
            loss = loss / grad_accum_steps
            loss.backward()
            accum_loss += loss.item()

        # Gradient clipping
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()

        pbar.set_postfix({"loss": f"{accum_loss:.4f}", "lr": f"{lr:.2e}"})

        # Evaluation & Checkpoint
        if step > 0 and step % eval_interval == 0:
            val_loss, perplexity = estimate_loss(model, val_loader, device)
            print(f"\n[Step {step:05d}] Train Loss: {accum_loss:.4f} | Val Loss: {val_loss:.4f} | PPL: {perplexity:.2f}")

            # Quick sample generation
            prompt_context = "The"
            ctx_ids = torch.tensor([tokenizer.encode(prompt_context)], device=device)
            generated_ids = model.generate(ctx_ids, max_new_tokens=40, temperature=0.8)
            sample_text = tokenizer.decode(generated_ids[0].tolist())
            print(f"Generated Preview: {sample_text}\n")

            if val_loss < best_val_loss:
                best_val_loss = val_loss
                torch.save({
                    "step": step,
                    "model_state_dict": model.state_dict(),
                    "optimizer_state_dict": optimizer.state_dict(),
                    "val_loss": val_loss,
                    "config": {
                        "vocab_size": tokenizer.vocab_size,
                        "n_layers": 4,
                        "n_embd": 128,
                        "n_head": 4,
                        "block_size": 256,
                    }
                }, "checkpoints/best_model.pt")
                print(f"⭐ Saved new best checkpoint with Val Loss: {val_loss:.4f}")

    total_time = time.time() - start_time
    print(f"\n🎉 Training Complete in {total_time/60:.2f} minutes!")
    print("Final checkpoint saved at checkpoints/best_model.pt")


if __name__ == "__main__":
    train()
