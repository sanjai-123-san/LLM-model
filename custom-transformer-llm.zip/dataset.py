"""
=============================================================================
Dataset & DataLoader Module
Memory-efficient causal sequence chunking for PyTorch LLM training
=============================================================================
"""

import torch
from torch.utils.data import Dataset, DataLoader
from typing import Tuple


class TextChunkDataset(Dataset):
    """
    Autoregressive Next-Token Prediction Dataset.
    Chunks continuous 1D tokenized stream into overlapping windows:
    x = tokens[i : i + block_size]
    y = tokens[i + 1 : i + block_size + 1]
    """
    def __init__(self, data_tensor: torch.Tensor, block_size: int = 256):
        self.data = data_tensor
        self.block_size = block_size

    def __len__(self) -> int:
        return max(1, len(self.data) - self.block_size)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        chunk = self.data[idx : idx + self.block_size + 1]
        x = chunk[:-1]
        y = chunk[1:]
        return x, y


def prepare_dataloaders(
    tokens: list,
    block_size: int = 256,
    batch_size: int = 32,
    train_split: float = 0.9,
    num_workers: int = 0,
) -> Tuple[DataLoader, DataLoader]:
    data_tensor = torch.tensor(tokens, dtype=torch.long)
    n = int(train_split * len(data_tensor))
    train_data = data_tensor[:n]
    val_data = data_tensor[n:]

    train_dataset = TextChunkDataset(train_data, block_size=block_size)
    val_dataset = TextChunkDataset(val_data, block_size=block_size)

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=num_workers, drop_last=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers, drop_last=False)

    return train_loader, val_loader
