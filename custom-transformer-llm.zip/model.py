"""
=============================================================================
Nano-GPT (1.2M) - PyTorch Transformer Architecture
Autoregressive Causal Language Model with RoPE and SwiGLU / Pre-LayerNorm
=============================================================================
"""

import math
from typing import Optional, Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F


class RMSNorm(nn.Module):
    """Root Mean Square Layer Normalization (Zhang & Sennrich, 2019)"""
    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))

    def _norm(self, x: torch.Tensor) -> torch.Tensor:
        return x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        output = self._norm(x.float()).type_as(x)
        return output * self.weight


def precompute_rope_freqs_cis(dim: int, max_seq_len: int, theta: float = 10000.0) -> torch.Tensor:
    """Precompute rotary positional embedding frequency cis."""
    freqs = 1.0 / (theta ** (torch.arange(0, dim, 2)[: (dim // 2)].float() / dim))
    t = torch.arange(max_seq_len, device=freqs.device)
    freqs = torch.outer(t, freqs).float()
    freqs_cis = torch.polar(torch.ones_like(freqs), freqs)  # complex64
    return freqs_cis


def apply_rotary_emb(xq: torch.Tensor, xk: torch.Tensor, freqs_cis: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
    """Apply Rotary Position Embeddings to Query and Key tensors."""
    xq_ = torch.view_as_complex(xq.float().reshape(*xq.shape[:-1], -1, 2))
    xk_ = torch.view_as_complex(xk.float().reshape(*xk.shape[:-1], -1, 2))
    
    # Broadcast freqs_cis over batch and heads
    freqs_cis = freqs_cis[: xq.shape[1], :].unsqueeze(0).unsqueeze(2)
    xq_out = torch.view_as_real(xq_ * freqs_cis).flatten(3)
    xk_out = torch.view_as_real(xk_ * freqs_cis).flatten(3)
    return xq_out.type_as(xq), xk_out.type_as(xk)


class SwiGLUMLP(nn.Module):
    """SwiGLU Feed-Forward Network (Shazeer, 2020)"""
    def __init__(self, d_model: int, hidden_dim: Optional[int] = None, dropout: float = 0.0):
        super().__init__()
        hidden_dim = hidden_dim or int(2 * (4 * d_model) / 3)
        self.w1 = nn.Linear(d_model, hidden_dim, bias=False)  # Gate proj
        self.w2 = nn.Linear(hidden_dim, d_model, bias=False)  # Down proj
        self.w3 = nn.Linear(d_model, hidden_dim, bias=False)  # Up proj
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # SwiGLU: (Swish(xW1) * xW3) W2
        return self.dropout(self.w2(F.silu(self.w1(x)) * self.w3(x)))


class StandardMLP(nn.Module):
    """Standard 4x Expansion MLP with GELU/ReLU"""
    def __init__(self, d_model: int, dropout: float = 0.0, activation: str = "gelu"):
        super().__init__()
        self.fc1 = nn.Linear(d_model, 4 * d_model)
        self.act = nn.GELU() if activation == "gelu" else nn.ReLU()
        self.fc2 = nn.Linear(4 * d_model, d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.dropout(self.fc2(self.act(self.fc1(x))))


class CausalSelfAttention(nn.Module):
    """Multi-Head Causal Self Attention with RoPE and FlashAttention integration"""
    def __init__(
        self,
        d_model: int = 128,
        n_head: int = 4,
        block_size: int = 256,
        dropout: float = 0.05,
        use_rope: bool = true,
        bias: bool = false,
    ):
        super().__init__()
        assert d_model % n_head == 0, "d_model must be divisible by n_head"
        self.d_model = d_model
        self.n_head = n_head
        self.head_dim = d_model // n_head
        self.use_rope = use_rope

        # Linear projections for Query, Key, Value
        self.q_proj = nn.Linear(d_model, d_model, bias=bias)
        self.k_proj = nn.Linear(d_model, d_model, bias=bias)
        self.v_proj = nn.Linear(d_model, d_model, bias=bias)
        self.out_proj = nn.Linear(d_model, d_model, bias=bias)
        self.dropout = dropout

        # Causal mask for standard attention
        self.register_buffer(
            "causal_mask",
            torch.tril(torch.ones(block_size, block_size)).view(1, 1, block_size, block_size),
            persistent=False,
        )

    def forward(
        self,
        x: torch.Tensor,
        freqs_cis: Optional[torch.Tensor] = None,
        kv_cache: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    ) -> Tuple[torch.Tensor, Optional[Tuple[torch.Tensor, torch.Tensor]]]:
        B, T, C = x.shape

        q = self.q_proj(x).view(B, T, self.n_head, self.head_dim)
        k = self.k_proj(x).view(B, T, self.n_head, self.head_dim)
        v = self.v_proj(x).view(B, T, self.n_head, self.head_dim)

        if self.use_rope and freqs_cis is not None:
            q, k = apply_rotary_emb(q, k, freqs_cis)

        # Transpose to (B, n_head, T, head_dim)
        q = q.transpose(1, 2)
        k = k.transpose(1, 2)
        v = v.transpose(1, 2)

        if kv_cache is not None:
            past_k, past_v = kv_cache
            k = torch.cat([past_k, k], dim=2)
            v = torch.cat([past_v, v], dim=2)
        new_kv_cache = (k, v)

        # Use PyTorch 2.0+ Scaled Dot Product FlashAttention
        if hasattr(F, "scaled_dot_product_attention"):
            out = F.scaled_dot_product_attention(
                q, k, v,
                attn_mask=None,
                dropout_p=self.dropout if self.training else 0.0,
                is_causal=True if kv_cache is None else False,
            )
        else:
            # Manual fallback
            att = (q @ k.transpose(-2, -1)) * (1.0 / math.sqrt(self.head_dim))
            att = att.masked_fill(self.causal_mask[:, :, :T, :T] == 0, float("-inf"))
            att = F.softmax(att, dim=-1)
            att = F.dropout(att, p=self.dropout, training=self.training)
            out = att @ v

        out = out.transpose(1, 2).contiguous().view(B, T, C)
        return self.out_proj(out), new_kv_cache


class TransformerBlock(nn.Module):
    """Transformer Decoder Block with Pre-Normalization residual connection"""
    def __init__(
        self,
        d_model: int = 128,
        n_head: int = 4,
        block_size: int = 256,
        dropout: float = 0.05,
        norm_type: str = "rmsnorm",
        activation: str = "swiglu",
        use_rope: bool = true,
    ):
        super().__init__()
        self.norm1 = RMSNorm(d_model) if norm_type == "rmsnorm" else nn.LayerNorm(d_model)
        self.attn = CausalSelfAttention(
            d_model=d_model,
            n_head=n_head,
            block_size=block_size,
            dropout=dropout,
            use_rope=use_rope,
        )
        self.norm2 = RMSNorm(d_model) if norm_type == "rmsnorm" else nn.LayerNorm(d_model)
        
        if activation == "swiglu":
            self.mlp = SwiGLUMLP(d_model, dropout=dropout)
        else:
            self.mlp = StandardMLP(d_model, dropout=dropout, activation=activation)

    def forward(
        self,
        x: torch.Tensor,
        freqs_cis: Optional[torch.Tensor] = None,
        kv_cache: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    ) -> Tuple[torch.Tensor, Optional[Tuple[torch.Tensor, torch.Tensor]]]:
        # Pre-Norm Attention
        normed_x = self.norm1(x)
        attn_out, new_kv_cache = self.attn(normed_x, freqs_cis=freqs_cis, kv_cache=kv_cache)
        x = x + attn_out

        # Pre-Norm FeedForward
        x = x + self.mlp(self.norm2(x))
        return x, new_kv_cache


class CustomLLM(nn.Module):
    """
    Complete Custom Transformer Language Model
    Config: Nano-GPT (1.2M) (0.92M parameters)
    """
    def __init__(
        self,
        vocab_size: int = 1024,
        n_layers: int = 4,
        n_embd: int = 128,
        n_head: int = 4,
        block_size: int = 256,
        dropout: float = 0.05,
        norm_type: str = "rmsnorm",
        activation: str = "swiglu",
        positional_encoding: str = "rope",
        bias: bool = false,
    ):
        super().__init__()
        self.vocab_size = vocab_size
        self.block_size = block_size
        self.n_layers = n_layers
        self.n_embd = n_embd
        self.positional_encoding = positional_encoding

        # Token embedding
        self.token_embeddings = nn.Embedding(vocab_size, n_embd)
        
        # Absolute positional embeddings if not using RoPE
        if positional_encoding == "learned":
            self.pos_embeddings = nn.Embedding(block_size, n_embd)
        elif positional_encoding == "rope":
            freqs_cis = precompute_rope_freqs_cis(n_embd // n_head, block_size)
            self.register_buffer("freqs_cis", freqs_cis, persistent=False)

        self.drop = nn.Dropout(dropout)

        # Transformer blocks
        self.blocks = nn.ModuleList([
            TransformerBlock(
                d_model=n_embd,
                n_head=n_head,
                block_size=block_size,
                dropout=dropout,
                norm_type=norm_type,
                activation=activation,
                use_rope=(positional_encoding == "rope"),
            )
            for _ in range(n_layers)
        ])

        # Final LayerNorm & Language Model Head
        self.final_norm = RMSNorm(n_embd) if norm_type == "rmsnorm" else nn.LayerNorm(n_embd)
        self.lm_head = nn.Linear(n_embd, vocab_size, bias=False)

        # Weight tying (Press & Wolf, 2016)
        self.token_embeddings.weight = self.lm_head.weight

        # Weight initialization
        self.apply(self._init_weights)

    def _init_weights(self, module: nn.Module):
        if isinstance(module, nn.Linear):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                torch.nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def forward(
        self,
        idx: torch.Tensor,
        targets: Optional[torch.Tensor] = None,
        kv_caches: Optional[list] = None,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[list]]:
        device = idx.device
        B, T = idx.shape
        assert T <= self.block_size, f"Sequence length {T} exceeds block size {self.block_size}"

        # Embeddings
        x = self.token_embeddings(idx)
        if self.positional_encoding == "learned":
            pos = torch.arange(0, T, dtype=torch.long, device=device)
            x = x + self.pos_embeddings(pos)
        x = self.drop(x)

        freqs_cis = getattr(self, "freqs_cis", None)
        if freqs_cis is not None:
            freqs_cis = freqs_cis.to(device)

        new_kv_caches = []
        for i, block in enumerate(self.blocks):
            past_cache = kv_caches[i] if kv_caches is not None else None
            x, cache = block(x, freqs_cis=freqs_cis, kv_cache=past_cache)
            if cache is not None:
                new_kv_caches.append(cache)

        x = self.final_norm(x)

        if targets is not None:
            # Training: compute CrossEntropy loss across full sequence
            logits = self.lm_head(x)
            loss = F.cross_entropy(logits.view(-1, logits.size(-1)), targets.view(-1), ignore_index=-1)
        else:
            # Inference: only compute logits for the last token position
            logits = self.lm_head(x[:, [-1], :])
            loss = None

        return logits, loss, (new_kv_caches if kv_caches is not None else None)

    @torch.no_grad()
    def generate(
        self,
        idx: torch.Tensor,
        max_new_tokens: int = 150,
        temperature: float = 0.8,
        top_k: int = 40,
        top_p: float = 0.9,
        repetition_penalty: float = 1.1,
    ) -> torch.Tensor:
        """Autoregressive text generation with sampling."""
        self.eval()
        for _ in range(max_new_tokens):
            idx_cond = idx if idx.size(1) <= self.block_size else idx[:, -self.block_size:]
            logits, _, _ = self(idx_cond)
            logits = logits[:, -1, :] / max(temperature, 1e-5)

            # Repetition penalty
            if repetition_penalty != 1.0:
                for token_id in set(idx[0].tolist()):
                    logits[0, token_id] /= repetition_penalty

            # Top-K filtering
            if top_k is not None and top_k > 0:
                v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
                logits[logits < v[:, [-1]]] = -float("Inf")

            # Top-P (nucleus) filtering
            if top_p is not None and top_p < 1.0:
                sorted_logits, sorted_indices = torch.sort(logits, descending=True)
                cumulative_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)
                sorted_indices_to_remove = cumulative_probs > top_p
                sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
                sorted_indices_to_remove[..., 0] = 0
                indices_to_remove = sorted_indices[sorted_indices_to_remove]
                logits[:, indices_to_remove] = -float("Inf")

            probs = F.softmax(logits, dim=-1)
            idx_next = torch.multinomial(probs, num_samples=1)
            idx = torch.cat((idx, idx_next), dim=1)

        return idx

    def configure_optimizers(self, weight_decay: float, learning_rate: float, betas: tuple, device_type: str):
        """Separate parameters into weight decay and non-decay (biases/LayerNorms)."""
        decay_params = [p for n, p in self.named_parameters() if p.requires_grad and p.dim() >= 2]
        nodecay_params = [p for n, p in self.named_parameters() if p.requires_grad and p.dim() < 2]
        
        optim_groups = [
            {"params": decay_params, "weight_decay": weight_decay},
            {"params": nodecay_params, "weight_decay": 0.0},
        ]
        
        optimizer = torch.optim.AdamW(optim_groups, lr=learning_rate, betas=betas)
        return optimizer
