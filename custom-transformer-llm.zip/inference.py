"""
=============================================================================
Interactive Inference & Chat Interface
Test your trained custom LLM in terminal or interactive REPL
=============================================================================
"""

import argparse
import sys
import torch
from model import CustomLLM
from tokenizer import CharTokenizer


def main():
    parser = argparse.ArgumentParser(description="Inference CLI for Custom LLM")
    parser.add_argument("--checkpoint", type=str, default="checkpoints/best_model.pt", help="Path to checkpoint")
    parser.add_argument("--tokenizer", type=str, default="checkpoints/tokenizer.json", help="Path to tokenizer")
    parser.add_argument("--prompt", type=str, default="To be, or not to be", help="Starting prompt")
    parser.add_argument("--max_tokens", type=int, default=150, help="Max new tokens to generate")
    parser.add_argument("--temperature", type=float, default=0.8, help="Sampling temperature")
    parser.add_argument("--top_k", type=int, default=40, help="Top-K sampling")
    parser.add_argument("--interactive", action="store_true", help="Start interactive chat REPL")
    args = parser.parse_args()

    device = "cuda" if torch.cuda.is_available() else ("mps" if torch.backends.mps.is_available() else "cpu")
    print(f"Loading model on {device}...")

    tokenizer = CharTokenizer.load(args.tokenizer)

    # Load weights
    ckpt = torch.load(args.checkpoint, map_location=device)
    config = ckpt.get("config", {})

    model = CustomLLM(
        vocab_size=config.get("vocab_size", tokenizer.vocab_size),
        n_layers=config.get("n_layers", 4),
        n_embd=config.get("n_embd", 128),
        n_head=config.get("n_head", 4),
        block_size=config.get("block_size", 256),
        norm_type="rmsnorm",
        activation="swiglu",
        positional_encoding="rope",
    ).to(device)

    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()
    print("✨ Model successfully loaded and ready!\n")

    if args.interactive:
        print("=== Custom LLM Interactive REPL (type 'exit' to quit) ===")
        while True:
            try:
                user_input = input("\nPrompt > ")
                if user_input.strip().lower() in ["exit", "quit"]:
                    break
                if not user_input.strip():
                    continue

                input_ids = torch.tensor([tokenizer.encode(user_input)], dtype=torch.long, device=device)
                out_ids = model.generate(
                    input_ids,
                    max_new_tokens=args.max_tokens,
                    temperature=args.temperature,
                    top_k=args.top_k,
                )
                print("\nGenerated:")
                print(tokenizer.decode(out_ids[0].tolist()))
            except KeyboardInterrupt:
                break
    else:
        print(f"Prompt: {args.prompt}\n")
        input_ids = torch.tensor([tokenizer.encode(args.prompt)], dtype=torch.long, device=device)
        out_ids = model.generate(
            input_ids,
            max_new_tokens=args.max_tokens,
            temperature=args.temperature,
            top_k=args.top_k,
        )
        print("Generated Output:")
        print(tokenizer.decode(out_ids[0].tolist()))


if __name__ == "__main__":
    main()
