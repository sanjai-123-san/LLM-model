# custom-transformer-llm

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com)
[![PyTorch](https://img.shields.io/badge/PyTorch-2.0%2B-EE4C2C.svg?logo=pytorch)](https://pytorch.org)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Parameters](https://img.shields.io/badge/Parameters-0.92M-blue.svg)](https://github.com)

> A production-grade PyTorch autoregressive Transformer Language Model with Rotary Position Embeddings (RoPE), SwiGLU activations, and FlashAttention.

---

## 🌟 Key Highlights

- **Autoregressive Transformer Decoder**: Built from scratch in pure PyTorch with zero black-box wrappers.
- **Modern LLM Innovations**:
  - 🔄 **RoPE (Rotary Position Embeddings)**: Enables length generalization and relative positional reasoning.
  - ⚡ **SwiGLU Activation**: Faster convergence and expressive non-linear representations.
  - 📐 **RMSNorm (Root Mean Square Normalization)**: Stable FP16/BF16 training dynamics.
  - 🚀 **FlashAttention-2 Support**: Seamless hardware acceleration via `torch.nn.functional.scaled_dot_product_attention`.
- **Complete End-to-End Suite**: Character & BPE Tokenizer, Dataset Chunking, Cosine Annealing LR Scheduler, Checkpointing, and Interactive CLI REPL.
- **Colab Ready**: Single-click executable `colab_training.ipynb` running on free Google Colab T4 GPU.

---

## 🏛️ Model Architecture Specifications

| Hyperparameter | Value | Description |
| :--- | :--- | :--- |
| **Model Size** | **0.92M** Parameters | Total trainable weights |
| **Layers (`n_layers`)** | **4** | Transformer decoder blocks |
| **Hidden Dimension (`d_model`)** | **128** | Embedding / channel dimension |
| **Attention Heads (`n_head`)** | **4** | Multi-head attention heads |
| **Head Dimension (`d_k`)** | **32** | Dimension per head |
| **Context Window (`block_size`)** | **256** Tokens | Maximum context sequence length |
| **Vocabulary Size** | **1024** | Unique token representations |
| **Normalization** | **RMSNORM** | Pre-layer normalization |
| **Activation Function** | **SWIGLU** | Feed-forward gate activation |
| **Positional Encoding** | **ROPE** | Rotary vs Learned embeddings |

---

## 🚀 Quickstart Guide

### 1. Clone & Setup Environment

```bash
git clone https://github.com/sanjai86/custom-transformer-llm.git
cd custom-transformer-llm

python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Train the Model

```bash
python train.py
```

The script automatically tokenizes `data/train.txt`, trains the model using AdamW with cosine learning rate decay, logs training/validation loss, and saves the best model checkpoint to `checkpoints/best_model.pt`.

### 3. Interactive Inference & Generation

```bash
# Single generation prompt
python inference.py --prompt "To be, or not to be" --temperature 0.8 --max_tokens 150

# Interactive REPL chat session
python inference.py --interactive
```

---

## 📁 Repository Structure

```
├── model.py                # PyTorch LLM Architecture (RoPE, SwiGLU, RMSNorm, Multi-Head Attention)
├── tokenizer.py            # Tokenizer engine (Character & BPE)
├── dataset.py              # PyTorch Dataset and DataLoader chunking
├── train.py                # Training loop with AdamW, Cosine LR, and checkpointing
├── inference.py            # Interactive CLI chat & text generation interface
├── config.yaml             # Architecture & training hyperparameters
├── colab_training.ipynb    # Google Colab ready-to-run Jupyter notebook
├── requirements.txt        # Python dependency manifest
├── Dockerfile              # Containerized training environment
└── data/
    └── train.txt           # Training corpus dataset
```

---

## 📊 Training Configuration

- **Optimizer**: AdamW (weight_decay=0.1)
- **Learning Rate**: 0.0005 (Warmup: 100 steps, Decay: Cosine Annealing to 0.00005)
- **Batch Size**: 32 × 4 Gradient Accumulation Steps
- **Hardware Requirement**: 1x NVIDIA T4 GPU (Google Colab free tier) or Apple Silicon MPS / CPU.

---

## 📜 License & Acknowledgments

This project is licensed under the **MIT License** - see the [LICENSE](LICENSE) file for details.

Developed with ❤️ by **Sanjai Kumar** for project demonstration and open-source dissemination.
